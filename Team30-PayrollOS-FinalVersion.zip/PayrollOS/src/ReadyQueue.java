import java.util.LinkedList;
import java.util.Queue;

public class ReadyQueue {
	
	Queue<Process> readyQueue,tempQueue;
	
	public ReadyQueue(){
		readyQueue = new LinkedList<Process>();
		tempQueue = new LinkedList<Process>();	
	}
	
	public void InsertJob(Process p){
		readyQueue.add(p);
		tempQueue.add(p);
	}

}

