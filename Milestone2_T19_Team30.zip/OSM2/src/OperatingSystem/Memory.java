package OperatingSystem;


public class Memory {
		
	public Process[] mainMemory;

	//most operations on memory (obtaining process, checking it exists)
	//is done using array regular methods and manipulation using indices...etc
	
	//can obtain next available space for new processes
	
	//might create delegate methods in later milestones if further 
	//functions are needed
	
}
