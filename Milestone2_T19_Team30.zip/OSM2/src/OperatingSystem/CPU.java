package OperatingSystem;

public class CPU {

		//this class handles the execution of the process that
		//needs to be run (first out of the runningQueue) 
		
		//it extracts the process from the memory using the PCB of the process
		//to get its location in the memory and proceeds to implement
		//the jobs of that process until the process is finished
	
	
}
