package OperatingSystem;

import java.util.Queue;
import Processes.PCB;

public class Scheduler {

		public static Queue<PCB> readyQueue; //contains elements waiting to be executed (their turn on the CPU)
		public static Queue<PCB> runningQueue; //contains elements that are allowed to be executed but are waiting their turn (since only 1 process can be run on the CPU)
		
		public void schedulerRunning() {
			
			//its always running (separate thread), if running Queue contains less than 2 objects it moves 
			//1 or 2 objects from readyQueue to the runningQueue 
			
			//when its a process's turn to be out of the runningQueue, 
			//it sends it to the CPU where it can be executed once 
			//and for all
			
		}
		
		
}
