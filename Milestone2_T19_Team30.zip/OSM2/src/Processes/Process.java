package Processes;

abstract class Process {  //abstract?
		
		private int processID;
		private PCB processPCB;
		
		public Process(int processID, PCB processPCB) {
			this.processID = processID;
			this.processPCB = processPCB;
		}

		public int getProcessID() {
			return processID;
		}

		public PCB getProcessPCB() {
			return processPCB;
		}
		
		public static void run() {  //if method is abstract, when apps extend it, will have to have their own run methods 
			
		}
		
}
