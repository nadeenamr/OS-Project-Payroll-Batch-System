package Processes;

public class PCB {
	
		private int processID;
		private State processStatus;
		private int processMemoryAddress;
		
		public PCB(int id, int address) {
			this.processID=id;
			this.processMemoryAddress=address;
			this.processStatus=State.NEW;
		}
	
		public int getProcessID() {
			return processID;
		}
	
		public State getProcessStatus() {
			return processStatus;
		}
	
		public void setProcessStatus(State processStatus) {
			this.processStatus = processStatus;
		}
	
		public int getProcessMemoryAddress() {
			return processMemoryAddress;
		}
	
		public void setProcessMemoryAddress(int processMemoryAddress) {
			this.processMemoryAddress = processMemoryAddress;
		}
		
		//when a state of a process is set to be ready, want to insert its PCB in the readyQueue in OS class
}
