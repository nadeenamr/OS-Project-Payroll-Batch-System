package Processes;

import OperatingSystem.IO;
import OperatingSystem.Scheduler;

public class PayLoanInstallment extends Process{
	
	//runs when called upon
	
	//user enters amount he wants to pay and his financial
	//data is updated on csv file
	
	//attributes?
	
	public PayLoanInstallment(int processMemoryAddress, int processID) {
		super(processID, processMemoryAddress);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
	}

	@Override
	public void print(String s) throws InterruptedException {
		Scheduler.console.acquire();
		IO.printToConsole((Process)this, "Acquired Console Semaphore");
		IO.printToConsole((Process)this, s);
		IO.printToConsole((Process)this, "Releasing Console Semaphore");
		Scheduler.console.release();
		
	}

}
