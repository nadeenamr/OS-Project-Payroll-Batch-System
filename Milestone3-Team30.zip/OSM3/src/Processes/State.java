package Processes;

public enum State {
	 	NEW, READY, BLOCKED, RUNNING, FINISHED
}
