package Processes;

public abstract class Process {  //abstract? interface?
		
		private int processID;
		private State processStatus;
		private int processMemoryAddress;
		//memory requirement attribute?
		
		public Process(int processID, int address) {
			this.processID = processID;
			this.processMemoryAddress=address;
			this.processStatus=State.NEW;
		}

		public int getProcessID() {
			return processID;
		}
		
		public State getProcessStatus() {
			return processStatus;
		}
	
		public void setProcessStatus(State processStatus) {
			this.processStatus = processStatus;
		}
	
		public int getProcessMemoryAddress() {
			return processMemoryAddress;
		}
	
		public void setProcessMemoryAddress(int processMemoryAddress) {
			this.processMemoryAddress = processMemoryAddress;
		}
		
		public abstract void run() ;		//if any process tried to run while another process is in the running queue
											//will place in ready queue
		
		public abstract void print(String s) throws InterruptedException;
		
		
}
