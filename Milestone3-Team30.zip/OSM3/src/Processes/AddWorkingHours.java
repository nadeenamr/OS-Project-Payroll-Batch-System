package Processes;

import OperatingSystem.IO;
import OperatingSystem.Scheduler;

public class AddWorkingHours extends Process {
	
	//always running
	
	//process that adds to the working hours of every employee
	//adds an hour every 30 seconds and when reaches 4 minutes will stop for 
	//2 minutes (to signify end of day and start of new one)
	//then commence counting once more
	
	//attributes?

	public AddWorkingHours(int processMemoryAddress, int processID) {
		super(processID, processMemoryAddress);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void print(String s) throws InterruptedException {
		Scheduler.console.acquire();
		IO.printToConsole((Process)this, "Acquired Console Semaphore");
		IO.printToConsole((Process)this, s);
		IO.printToConsole((Process)this, "Releasing Console Semaphore");
		Scheduler.console.release();
		
	}

}
