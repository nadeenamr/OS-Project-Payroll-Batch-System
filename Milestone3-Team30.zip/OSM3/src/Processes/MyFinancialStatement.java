package Processes;

import OperatingSystem.IO;
import OperatingSystem.Scheduler;

public class MyFinancialStatement extends Process{
	
	//runs when called
	
	//user wants to see every piece of info that is recorded about him in csv logfile
	//ex. working hours so far, salary so far, loan owed, bonus, when is payment due (salary)
	//will print it on console or create csv file?
	
	//attributes?

	public MyFinancialStatement(int processMemoryAddress, int processID) {
		super(processID, processMemoryAddress);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
	}

	@Override
	public void print(String s) throws InterruptedException {
		Scheduler.console.acquire();
		IO.printToConsole((Process)this, "Acquired Console Semaphore");
		IO.printToConsole((Process)this, s);
		IO.printToConsole((Process)this, "Releasing Console Semaphore");
		Scheduler.console.release();
	}
	
	

}
