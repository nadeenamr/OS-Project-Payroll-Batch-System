package OperatingSystem;

import java.util.Queue;
import java.util.concurrent.Semaphore;

import Processes.Process;

public class Scheduler {

		public static Queue<Process> readyQueue; 						//contains elements waiting to be executed (their turn on the CPU)
		public static Queue<Process> blockedQueue;						//contains Processes waiting for CSV file (maybe memory too, or that in ready again?)
		public static Queue<Process> runningQueue; 						//contains elements that are allowed to be executed but are waiting their turn 
																		//(since only 1 process can be run on the CPU)
		public static Semaphore logFile = new Semaphore(1);				//semaphore to access control to CSV file
		public static Semaphore console = new Semaphore(1);				//not sure about start value, semaphore to access 
		
		public void schedulerRunning() {
			while(true) {
				if(runningQueue.isEmpty()) {
					runningQueue.add(readyQueue.poll());
				}
			}
			//its always running (separate thread), if running Queue contains less than 2 objects it moves 
			//1 or 2 objects from readyQueue to the runningQueue 
			
			//when its a process's turn to be out of the runningQueue, 
			//it sends it to the CPU where it can be executed once 
			//and for all
			
		}
		
		public void killProcess(Process p) {
			if(readyQueue.contains(p)) {
				readyQueue.remove(p);
			}else {
				if(runningQueue.contains(p)) {
					runningQueue.remove(p);
				}else {
					if(blockedQueue.contains(p)) {
						blockedQueue.remove(p);
					}
				}
			}
		}
		
		
}
