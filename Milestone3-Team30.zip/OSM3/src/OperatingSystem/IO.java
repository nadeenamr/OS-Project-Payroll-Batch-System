package OperatingSystem;

public class IO {
		
	//will be responsible for any access
	//to the console and has a semaphore 
	//to control its access
	
	public static void printToConsole(Processes.Process process, String s) {			//message displayed by a specific process
		System.out.println("Process "+process.getProcessID()+": "+s);
	}
	
	public static void printToConsole(String s) {						//message displayed from any entity in the OS 
		System.out.println(s);
	}
	
}
