package OperatingSystem;

public class Memory {
		
	public static Object[] mainMemory = new Object[10];					//most operations on memory (obtaining process, checking it exists)
	private static int memorySize = 10;											//is done using array regular methods and manipulation using indices...etc
	private static int occupied =0;												//can obtain next available space for new processes
	
	public static Object assignMemory() {			//can return a string that is an error message or the index of the next available memory slot
		if(occupied==memorySize) {					//1st draft
			return "Memory Full";
		}
		int x = nextFreeSlot();
		occupied++;
		return x; 
	}
	
	public static int nextFreeSlot() { 					//since empty spaces are not always at end of array, will call this method to know which 
		for(int i=0; i<memorySize;i++) {				//spaces are empty to assign to peocesses in need
			if (mainMemory[i]==null) {
				return i;
			}
		}
		return -1;
	}
}
